

interface TodoAdd {
    title: string
    writer: string
}

interface TodoDTO {
    tno : number
    title: string
    writer: string
    regDate : string
    modDate : string
}

function App() {

  return (
    <>
      <div className={'text-4xl'}>
          Hello
      </div>
    </>
  )
}

export default App

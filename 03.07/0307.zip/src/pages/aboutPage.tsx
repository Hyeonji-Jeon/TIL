import CustomLayout from "../layouts/customLayout.tsx";

function AboutPage() {
    return (
        <CustomLayout>

            <h2 className="text-lg font-semibold">About Page</h2>

        </CustomLayout>
    );
}

export default AboutPage;
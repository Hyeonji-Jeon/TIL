import CustomLayout from "../layouts/customLayout.tsx";

function MainPage() {
    return (
        <CustomLayout>

            <h2 className="text-lg font-semibold">Main Page</h2>

        </CustomLayout>
    );
}

export default MainPage;